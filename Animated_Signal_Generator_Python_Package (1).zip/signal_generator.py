import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import TextBox, RadioButtons

# ANIMATED SIGNAL GENERATOR USING PYTHON

plt.style.use("dark_background")

# Default input values
A = 5.0
frequency = 2.0
duration = 2.0
dt = 0.005

signal_names = [
    "Sine Wave",
    "Cosine Wave",
    "Square Wave",
    "Triangular Wave",
    "Sawtooth Wave",
    "Exponential Decay",
    "Exponential Growth",
    "Damped Sine Wave"
]

def generate_signal(choice, time_values, amplitude, freq):
    """Return samples for the selected signal."""
    angular_frequency = 2 * np.pi * freq

    if choice == 1:
        return amplitude * np.sin(angular_frequency * time_values)
    elif choice == 2:
        return amplitude * np.cos(angular_frequency * time_values)
    elif choice == 3:
        return amplitude * np.sign(np.sin(angular_frequency * time_values))
    elif choice == 4:
        return (2 * amplitude / np.pi) * np.arcsin(
            np.sin(angular_frequency * time_values)
        )
    elif choice == 5:
        return amplitude * (
            2 * (freq * time_values - np.floor(freq * time_values)) - 1
        )
    elif choice == 6:
        return amplitude * np.exp(-2 * time_values)
    elif choice == 7:
        return amplitude * np.exp(0.8 * time_values)
    elif choice == 8:
        return (
            amplitude
            * np.exp(-2 * time_values)
            * np.sin(angular_frequency * time_values)
        )
    raise ValueError("Unknown signal selection.")

# Initial signal
time_values = np.arange(0, duration, dt)
signal_choice = 1
signal_values = generate_signal(signal_choice, time_values, A, frequency)

# Main window
fig, ax = plt.subplots(figsize=(12, 7))
plt.subplots_adjust(left=0.10, right=0.75, bottom=0.20, top=0.87)

fig.suptitle(
    "ANIMATED SIGNAL GENERATOR",
    fontsize=18,
    fontweight="bold",
    color="cyan"
)

ax.set_title("Live Signal Visualization")
ax.set_xlabel("Time (seconds)")
ax.set_ylabel("Amplitude")
ax.grid(True, alpha=0.30)

line, = ax.plot([], [], color="cyan", linewidth=2.5)
ax.set_xlim(0, duration)
ax.set_ylim(-A * 1.5, A * 1.5)

info_text = fig.text(
    0.77, 0.76,
    "Signal: Sine Wave\nAmplitude: 5\nFrequency: 2 Hz\nDuration: 2 sec",
    fontsize=10,
    color="white",
    bbox=dict(
        facecolor="#182635",
        edgecolor="cyan",
        boxstyle="round,pad=0.6"
    )
)

def animate(frame):
    """Draw the waveform progressively."""
    line.set_data(time_values[:frame], signal_values[:frame])
    return line,

animation = FuncAnimation(
    fig,
    animate,
    frames=len(time_values) + 1,
    interval=10,
    blit=True,
    repeat=True,
    cache_frame_data=False
)

# Signal selector
radio_ax = plt.axes([0.78, 0.35, 0.19, 0.35])
radio = RadioButtons(radio_ax, signal_names, active=0)

# Parameter input boxes
amp_ax = plt.axes([0.12, 0.08, 0.15, 0.05])
amp_box = TextBox(amp_ax, "Amplitude", initial="5")

freq_ax = plt.axes([0.36, 0.08, 0.15, 0.05])
freq_box = TextBox(freq_ax, "Frequency", initial="2")

duration_ax = plt.axes([0.60, 0.08, 0.15, 0.05])
duration_box = TextBox(duration_ax, "Duration", initial="2")

def update_signal(label):
    """Read inputs, validate them, and update the selected waveform."""
    global A, frequency, duration, time_values
    global signal_values, signal_choice

    try:
        new_amplitude = float(amp_box.text)
        new_frequency = float(freq_box.text)
        new_duration = float(duration_box.text)

        if new_amplitude <= 0 or new_frequency <= 0 or new_duration <= 0:
            print("Please enter positive values for amplitude, frequency, and duration.")
            return

        # Prevent an excessively large number of samples.
        if new_duration / dt > 500000:
            print("Duration is too large. Please use a shorter duration.")
            return

        A = new_amplitude
        frequency = new_frequency
        duration = new_duration
        signal_choice = signal_names.index(label) + 1

        time_values = np.arange(0, duration, dt)
        signal_values = generate_signal(
            signal_choice, time_values, A, frequency
        )

        ax.set_xlim(0, duration)
        max_value = max(float(np.max(np.abs(signal_values))), 1.0)
        ax.set_ylim(-max_value * 1.2, max_value * 1.2)

        info_text.set_text(
            f"Signal: {label}\n"
            f"Amplitude: {A:g}\n"
            f"Frequency: {frequency:g} Hz\n"
            f"Duration: {duration:g} sec"
        )

        # Restart the animation from the beginning with new data.
        animation.frame_seq = animation.new_frame_seq()
        fig.canvas.draw_idle()

    except ValueError:
        print("Invalid input. Enter numeric values only.")

radio.on_clicked(update_signal)

plt.show()
