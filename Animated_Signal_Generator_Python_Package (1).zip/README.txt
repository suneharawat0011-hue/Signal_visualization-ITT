ANIMATED SIGNAL GENERATOR - PYTHON PROJECT

FILES
-----
signal_generator.py : Complete Python source code
requirements.txt    : Required Python libraries

INSTALLATION
------------
1. Install Python 3.
2. Open Command Prompt or terminal in this folder.
3. Install requirements:

   python -m pip install -r requirements.txt

RUN
---
   python signal_generator.py

FEATURES
--------
- Eight signal types: sine, cosine, square, triangular, sawtooth,
  exponential decay, exponential growth, and damped sine.
- Animated waveform drawing.
- User inputs for amplitude, frequency, and duration.
- Interactive signal selection.

NOTES
-----
Run this project in a desktop Python environment that supports
Matplotlib graphical windows. The default sampling interval is 0.005 s.
